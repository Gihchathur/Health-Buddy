package com.gautam.medicinetime.doctor;

public class Member {
    private String name,speciality,hometown,number,imageid,latitute,logitute,special;

    public Member() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getImageid() {
        return imageid;
    }

    public void setImageid(String imageid) {
        this.imageid = imageid;
    }


    public String getLatitute() {
        return latitute;
    }

    public void setLatitute(String latitute) {
        this.latitute = latitute;
    }

    public String getLogitute() {
        return logitute;
    }

    public void setLogitute(String logitute) { this.logitute = logitute;
    }

    public String getSpecial() {
        return special;
    }

    public void setSpecial(String special) { this.special = special;}
}
