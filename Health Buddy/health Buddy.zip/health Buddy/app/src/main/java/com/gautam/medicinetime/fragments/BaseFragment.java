package com.gautam.medicinetime.fragments;

import android.view.View;

import androidx.fragment.app.Fragment;

/**
 * The top parent for all fragments
 */
public abstract class BaseFragment extends Fragment {

    protected abstract void initViews(View rootView);
}
