package com.gautam.medicinetime.profile;

public class UtilClips {
}
