package com.gautam.medicinetime.activities;

import android.app.Activity;
import android.os.Bundle;

import com.gautam.medicinetime.R;

/**
 * Created by Sakshi on 3/25/2018.
 */

public class CalorieCal extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculate1);
/*
        x = getIntent().getFloatExtra("N1", 0);
        y = getIntent().getFloatExtra("N2", 0);

        ans = (TextView) findViewById(R.id.ans);
        ans.setText(s1);

        Button caloriecal = (Button) findViewById(R.id.button6);
        caloriecal.setOnClickListener(new View.OnClickListener() {


*/

    }
}

