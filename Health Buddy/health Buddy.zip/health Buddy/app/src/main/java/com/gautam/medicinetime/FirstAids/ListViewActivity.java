package com.gautam.medicinetime.FirstAids;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.gautam.medicinetime.R;

public class ListViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

    }
}
