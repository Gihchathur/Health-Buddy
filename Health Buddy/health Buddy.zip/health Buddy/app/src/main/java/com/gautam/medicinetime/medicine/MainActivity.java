package com.gautam.medicinetime.medicine;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.activities.Bmi;
import com.gautam.medicinetime.activities.FoodActivity;
import com.gautam.medicinetime.activities.FoodMainActivity;
import com.gautam.medicinetime.doctor.DoctorRegActivity;
import com.gautam.medicinetime.doctor.SetupActivity;
import com.gautam.medicinetime.other.OtherActivity;
import com.gautam.medicinetime.predict.Description;
import com.gautam.medicinetime.predict.DiseasePredictMainActivity;
import com.gautam.medicinetime.predict.Disease_prediction;
import com.gautam.medicinetime.profile.ProfileRegActivity;

public class MainActivity extends AppCompatActivity {

    CardView profile_button,identify_button,doctor_button,alarm_button,foods_button,other_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        profile_button = findViewById(R.id.profile_button);
        doctor_button = findViewById(R.id.doctor_button);
        identify_button = findViewById(R.id.identify_button);
        alarm_button = findViewById(R.id.alarm_button);
        foods_button = findViewById(R.id.foods_button);
        other_button = findViewById(R.id.other_button);

        RunAnimation();

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        profile_button.startAnimation(myAnim);
        final Animation myAnim2 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        identify_button.startAnimation(myAnim2);
        final Animation myAnim3 = AnimationUtils.loadAnimation(this, R.anim.bounce3);
        doctor_button.startAnimation(myAnim3);
        final Animation myAnim6 = AnimationUtils.loadAnimation(this, R.anim.bounce4);
        alarm_button.startAnimation(myAnim6);
        final Animation myAnim4 = AnimationUtils.loadAnimation(this, R.anim.bounce5);
        foods_button.startAnimation(myAnim4);
        final Animation myAnim5 = AnimationUtils.loadAnimation(this, R.anim.bounce6);
        other_button.startAnimation(myAnim5);


        profile_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(MainActivity.this, ProfileRegActivity.class);
                startActivity(labIntent);
            }
        });
        doctor_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(MainActivity.this, SetupActivity.class);
                startActivity(labIntent);
            }
        });
        identify_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(MainActivity.this, DiseasePredictMainActivity.class);
                startActivity(labIntent);
            }
        });
        alarm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(MainActivity.this,MedicineActivity.class);
                startActivity(labIntent);
            }
        });
        foods_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(MainActivity.this, FoodMainActivity.class);
                startActivity(labIntent);
            }
        });
        other_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(MainActivity.this, OtherActivity.class);
                startActivity(labIntent);
            }
        });




    }

    private void RunAnimation()
    {
        Animation a = AnimationUtils.loadAnimation(this, R.anim.textanim);
        a.reset();
        TextView tv = (TextView) findViewById(R.id.user_name);
        tv.clearAnimation();
        tv.startAnimation(a);
        a = AnimationUtils.loadAnimation(this, R.anim.textanim2);
        a.reset();
        tv = (TextView) findViewById(R.id.user_name);
        tv.clearAnimation();
        tv.startAnimation(a);
    }
}
