package com.gautam.medicinetime.doctor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.medicine.MainActivity;
import com.gautam.medicinetime.medicine.MedicineActivity;
import com.google.firebase.auth.FirebaseAuth;

public class SetupActivity extends AppCompatActivity {
    Button btnLogout,btnSave;
    CardView profile_button,identify_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        profile_button = findViewById(R.id.profile_button);
        identify_button = findViewById(R.id.identify_button);

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        profile_button.startAnimation(myAnim);
        final Animation myAnim2 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        identify_button.startAnimation(myAnim2);

        profile_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SetupActivity.this, DoctorsListActivity.class);
                startActivity(labIntent);
            }
        });
        identify_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SetupActivity.this,doclogselect.class);
                startActivity(labIntent);
            }
        });


    }
}