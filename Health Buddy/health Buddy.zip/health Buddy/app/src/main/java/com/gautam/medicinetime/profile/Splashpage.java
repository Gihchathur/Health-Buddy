package com.gautam.medicinetime.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.gautam.medicinetime.R;



public class Splashpage extends AppCompatActivity {
    private final int SPLASH_DISPLAY_LENGTH = 3000;
    /** Called when the activity is first created. */
    ImageView image;
    TextView text1,text2;

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_splashpage);


        image = findViewById(R.id.imageView4);
        text1 =  findViewById(R.id.textView8);
        text2 =  findViewById(R.id.textView9);

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        image.startAnimation(myAnim);
        final Animation myAnim2 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        text1.startAnimation(myAnim2);
        final Animation myAnim3 = AnimationUtils.loadAnimation(this, R.anim.bounce3);
        text2.startAnimation(myAnim3);
        /* New Handler to start the Menu-Activity
         * and close this Splash-Screen after some seconds.*/
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                /* Create an Intent that will start the Menu-Activity. */
                Intent mainIntent = new Intent(Splashpage.this, LoginActivity.class);
                Splashpage.this.startActivity(mainIntent);
                Splashpage.this.finish();
            }
        }, SPLASH_DISPLAY_LENGTH);
    }
}