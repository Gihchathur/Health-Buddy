package com.gautam.medicinetime.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.doctor.DoctorHomeActivity;
import com.gautam.medicinetime.doctor.DoctorListActivity;
import com.gautam.medicinetime.doctor.SetupActivity;
import com.gautam.medicinetime.medicine.MainActivity;

public class ProfileRegActivity extends AppCompatActivity {

    Button savebutton,signout;
    ImageView NextImage,logout;
    EditText name,age,hometown,phonenumber;
    int PICK_IMAGE=1;
    public static final String PREFS_NAME = "MyPrefsFile";
    private static final String KEY_NAME = "Name";
    private static final String KEY_AGE = "Age";
    private static final String KEY_HOMETOWN = "Hometown";
    private static final String KEY_MOBILE = "Mobile Number";
    public Uri imguri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_profile_reg);
        name= findViewById(R.id.editText11);
        age =findViewById(R.id.editText22);
        hometown =findViewById(R.id.editText33);
        phonenumber =findViewById(R.id.editText44);
        NextImage =findViewById(R.id.next);
        logout =findViewById(R.id.lgot);
        SharedPreferences pref = getSharedPreferences("ActivityPREF", Context.MODE_PRIVATE);

        name.setText(pref.getString(KEY_NAME,null));
        age.setText(pref.getString(KEY_AGE,null));
        hometown.setText(pref.getString(KEY_HOMETOWN,null));
        phonenumber.setText(pref.getString(KEY_MOBILE,null));


        NextImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                SharedPreferences.Editor edt = pref.edit();
                edt.putString(KEY_NAME,name.getText().toString());
                edt.putString(KEY_AGE,age.getText().toString());
                edt.putString(KEY_HOMETOWN,hometown.getText().toString());
                edt.putString(KEY_MOBILE,phonenumber.getText().toString());
                edt.putBoolean("activity_executed", true);
                edt.commit();

                Intent labIntent = new Intent(ProfileRegActivity.this, MainActivity.class);
                startActivity(labIntent);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences pref = getSharedPreferences("ActivityPREF", Context.MODE_PRIVATE);
                SharedPreferences.Editor edt = pref.edit();
                edt.putString(KEY_NAME,null);
                edt.putString(KEY_AGE,null);
                edt.putString(KEY_HOMETOWN,null);
                edt.putString(KEY_MOBILE,null);
                edt.putBoolean("activity_executed", false);
                edt.commit();

                Intent labIntent = new Intent(ProfileRegActivity.this, LoginActivity.class);
                startActivity(labIntent);
            }
        });



    }


}