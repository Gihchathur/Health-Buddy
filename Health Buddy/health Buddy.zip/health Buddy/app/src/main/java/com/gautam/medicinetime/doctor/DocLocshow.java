package com.gautam.medicinetime.doctor;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;

import com.gautam.medicinetime.R;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;

public class DocLocshow extends AppCompatActivity {

    //private GoogleMap googleMap = ((MapView) rootView.findViewById(R.id.YOURMAPID)).getMap();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doc_locshow);

    }
}