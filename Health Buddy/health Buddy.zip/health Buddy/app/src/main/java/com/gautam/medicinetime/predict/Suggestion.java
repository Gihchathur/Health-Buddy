package com.gautam.medicinetime.predict;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.gautam.medicinetime.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Suggestion extends AppCompatActivity {

    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference mRootReference = firebaseDatabase.getReference();
    private DatabaseReference mDiseaseSpec = mRootReference.child("specialist");
    private DatabaseReference mDiseaseDetails = mRootReference.child("Doctor Details");

    String url, resultString;

    ArrayList<String> entry;

    private ListView detailListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestion);

        resultString = getIntent().getStringExtra("RESULT");
        Toast.makeText(this.getApplicationContext(), resultString, Toast.LENGTH_LONG).show();

        url="https://search.cdc.gov/search/?query="+resultString;
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);



    }
}
