package com.gautam.medicinetime.doctor;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.gautam.medicinetime.R;

class MyViewHolder extends RecyclerView.ViewHolder {

    TextView name,speciality,hometown;
    String number,photoid,latitute,longitute,special;
    LinearLayout layout;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);

        name=itemView.findViewById(R.id.nameDoc);
        speciality=itemView.findViewById(R.id.specialityDoc);
        hometown=itemView.findViewById(R.id.hometownDoc);
        latitute="6.842220";
        longitute="79.901189";


        layout= itemView.findViewById(R.id.layout);


    }
}
