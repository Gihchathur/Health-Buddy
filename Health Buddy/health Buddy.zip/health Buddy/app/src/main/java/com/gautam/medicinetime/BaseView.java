package com.gautam.medicinetime;

/**
 * Created by gautam on 12/07/17.
 */

public interface BaseView<T> {

    void setPresenter(T presenter);
}
