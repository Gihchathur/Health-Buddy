package com.gautam.medicinetime.other;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.activities.FoodActivity;
import com.gautam.medicinetime.doctor.SetupActivity;
import com.gautam.medicinetime.medicine.MainActivity;
import com.gautam.medicinetime.medicine.MedicineActivity;

public class SelectionActivity extends AppCompatActivity {
    CardView profile_button,identify_button,doctor_button,alarm_button,foods_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);
        profile_button = findViewById(R.id.profile_button2);
        doctor_button = findViewById(R.id.doctor_button2);
        identify_button = findViewById(R.id.identify_button2);
        alarm_button = findViewById(R.id.alarm_button2);
        foods_button = findViewById(R.id.foods_button2);


        //RunAnimation();

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        profile_button.startAnimation(myAnim);
        final Animation myAnim2 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        identify_button.startAnimation(myAnim2);
        final Animation myAnim3 = AnimationUtils.loadAnimation(this, R.anim.bounce3);
        doctor_button.startAnimation(myAnim3);
        final Animation myAnim6 = AnimationUtils.loadAnimation(this, R.anim.bounce4);
        alarm_button.startAnimation(myAnim6);
        final Animation myAnim4 = AnimationUtils.loadAnimation(this, R.anim.bounce5);
        foods_button.startAnimation(myAnim4);


        profile_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SelectionActivity.this, AddUserActivity.class);
                startActivity(labIntent);
            }
        });
        doctor_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SelectionActivity.this, AddUserActivity.class);
                startActivity(labIntent);
            }
        });
        identify_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SelectionActivity.this,AddUserActivity.class);
                startActivity(labIntent);
            }
        });
        alarm_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SelectionActivity.this,AddUserActivity.class);
                startActivity(labIntent);
            }
        });
        foods_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(SelectionActivity.this, AddUserActivity.class);
                startActivity(labIntent);
            }
        });


    }

    private void RunAnimation()
    {
        Animation a = AnimationUtils.loadAnimation(this, R.anim.textanim);
        a.reset();
        TextView tv = (TextView) findViewById(R.id.user_name);
        tv.clearAnimation();
        tv.startAnimation(a);

    }
}