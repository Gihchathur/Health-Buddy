package com.gautam.medicinetime.activities;

import androidx.appcompat.app.AppCompatActivity;

/**
 * The top parent for all activities
 */
public abstract class BaseActivity extends AppCompatActivity {

    protected abstract void initViews();
}
