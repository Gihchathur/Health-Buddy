package com.gautam.medicinetime.doctor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.activities.FoodMainActivity;
import com.gautam.medicinetime.medicine.MainActivity;
import com.gautam.medicinetime.medicine.MedicineActivity;
import com.gautam.medicinetime.other.OtherActivity;
import com.gautam.medicinetime.predict.DiseasePredictMainActivity;

public class DoctorsListActivity extends AppCompatActivity {

    CardView a,b,c,d,e,f,g,h,i,j,k,l,m,n,o;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors_list);

        a = findViewById(R.id.doctor_i1);
        b = findViewById(R.id.doctor_i2);
        c = findViewById(R.id.doctor_i3);
        d = findViewById(R.id.doctor_i4);
        e = findViewById(R.id.foods_i5);
        f = findViewById(R.id.other_i6);
        g = findViewById(R.id.other_i7);
        h = findViewById(R.id.other_i8);
        i = findViewById(R.id.other_i9);
        j = findViewById(R.id.other_i10);
        k = findViewById(R.id.other_i11);
        l = findViewById(R.id.other_i12);
        m = findViewById(R.id.other_i13);
        n = findViewById(R.id.other_i14);
        o = findViewById(R.id.other_i15);


        RunAnimation();

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        a.startAnimation(myAnim);
        final Animation myAnim2 = AnimationUtils.loadAnimation(this, R.anim.bounce);
        b.startAnimation(myAnim2);
        final Animation myAnim3 = AnimationUtils.loadAnimation(this, R.anim.bounce);
        c.startAnimation(myAnim3);
        final Animation myAnim6 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        d.startAnimation(myAnim6);
        final Animation myAnim4 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        e.startAnimation(myAnim4);
        final Animation myAnim5 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        f.startAnimation(myAnim5);
        final Animation myAnim7 = AnimationUtils.loadAnimation(this, R.anim.bounce3);
        g.startAnimation(myAnim7);
        final Animation myAnim8 = AnimationUtils.loadAnimation(this, R.anim.bounce3);
        h.startAnimation(myAnim8);
        final Animation myAnim9 = AnimationUtils.loadAnimation(this, R.anim.bounce3);
        i.startAnimation(myAnim9);
        final Animation myAnim11 = AnimationUtils.loadAnimation(this, R.anim.bounce4);
        j.startAnimation(myAnim11);
        final Animation myAnim22 = AnimationUtils.loadAnimation(this, R.anim.bounce4);
        k.startAnimation(myAnim22);
        final Animation myAnim33 = AnimationUtils.loadAnimation(this, R.anim.bounce4);
        l.startAnimation(myAnim33);
        final Animation myAnim44 = AnimationUtils.loadAnimation(this, R.anim.bounce5);
        m.startAnimation(myAnim44);
        final Animation myAnim55 = AnimationUtils.loadAnimation(this, R.anim.bounce5);
        n.startAnimation(myAnim55);
        final Animation myAnim66 = AnimationUtils.loadAnimation(this, R.anim.bounce5);
        o.startAnimation(myAnim66);



         a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Diabetes");
                startActivity(labIntent);
            }
        });
         b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Radiology");
                startActivity(labIntent);
            }
        });
         c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Neurology");
                startActivity(labIntent);
            }
        });
         d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Otology");
                startActivity(labIntent);
            }
        });
         e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Ophthalmology");
                startActivity(labIntent);
            }
        });
         f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Rhinology");
                startActivity(labIntent);
            }
        });
         g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Oral Health");
                startActivity(labIntent);
            }
        });
         h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Cardiology");
                startActivity(labIntent);
            }
        });
         i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Gastroenterology");
                startActivity(labIntent);
            }
        });
         j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Pulmonology");
                startActivity(labIntent);
            }
        });
         k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Hepatology");
                startActivity(labIntent);
            }
        });
         l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Gynecology");
                startActivity(labIntent);
            }
        });
         m.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Urology");
                startActivity(labIntent);
            }
        });
         n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Osteology");
                startActivity(labIntent);
            }
        });
        o.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent labIntent = new Intent(DoctorsListActivity.this, DoctorListActivity.class);
                labIntent.putExtra("spec", "Orthopedics");
                startActivity(labIntent);
            }
        });




    }

    private void RunAnimation()
    {
        Animation a = AnimationUtils.loadAnimation(this, R.anim.textanim);
        a.reset();
        TextView tv = (TextView) findViewById(R.id.user_name);
        tv.clearAnimation();
        tv.startAnimation(a);
        a = AnimationUtils.loadAnimation(this, R.anim.textanim2);
        a.reset();
        tv = (TextView) findViewById(R.id.user_name);
        tv.clearAnimation();
        tv.startAnimation(a);
    }

}