package com.gautam.medicinetime.models.services;

/**
 * Constants used in services
 */
public interface ServiceConstants {

    String AUTHORIZATION_HEADER = "Authorization: 5055538:e52b2981d949fea96d3a103643f377e1ab85c08e347e310adf5ed927831e1018";
    String BASE_SUFFIX_URL = "/icebox/v1/foods/en/se";
}
