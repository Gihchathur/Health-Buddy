package com.gautam.medicinetime.doctor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.gautam.medicinetime.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

public class DoctorRecycleActivity extends AppCompatActivity {

    TextView name,speciality,hometown,number,imageid;
    String name1,speciality1,hometown1,number1,imageid1,latitute,longitute;
    FirebaseStorage mStorage;
    Button btn;
    private StorageReference reff,first;

    ImageView profile,close;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_recycle);
        name=findViewById(R.id.textView3);
        speciality=findViewById(R.id.textView4);
        hometown=findViewById(R.id.textView5);
        number=findViewById(R.id.textView2);
        profile=findViewById(R.id.imageView);

        name1 = getIntent().getStringExtra("name");
        speciality1 = getIntent().getStringExtra("speciality");
        hometown1 = getIntent().getStringExtra("hometown");
        number1=getIntent().getStringExtra("number");
        imageid1=getIntent().getStringExtra("photoid");
        latitute=getIntent().getStringExtra("latitute");
        longitute=getIntent().getStringExtra("longitute");

        name.setText(name1);
        speciality.setText(speciality1);
        hometown.setText(hometown1);
        number.setText(number1);


        /*mStorage = FirebaseStorage.getInstance();
        reff=mStorage.getReferenceFromUrl("gs://healthy-buddy1995.appspot.com/images").child(imageid1);
        first=reff.child("images");*/

        String Str= "https://firebasestorage.googleapis.com/v0/b/healthy-buddy1995.appspot.com/o/Images%2F"+imageid1+"?alt=media&token=ce016851-fae0-485e-96ba-ea948724bbac";
        Picasso.get().load(Str).into(profile);

        close= findViewById(R.id.imageView2);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent=new Intent(DoctorRecycleActivity.this,DoctorListActivity.class);
                startActivity(Intent);
            }
        });

        String str="geo:"+latitute+","+longitute+"?q="+latitute+","+longitute;
        btn= findViewById(R.id.button2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri gmmIntentUri = Uri.parse(str);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                }
            }
        });

        number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = number1;
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
            }
        });


    }



}