package com.gautam.medicinetime.doctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.gautam.medicinetime.R;
import com.google.firebase.FirebaseAppLifecycleListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class DoctorListActivity extends AppCompatActivity {

    DatabaseReference ref;
    RecyclerView recyclerView;
    EditText search;
    String sech;
    Button searchbtn;

    private FirebaseRecyclerOptions<Member> options,options2;
    private FirebaseRecyclerAdapter<Member, MyViewHolder> adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);

        searchbtn = findViewById(R.id.searchbtn);
        Intent intent = getIntent();
        String var1 = intent.getStringExtra("spec");

        search = findViewById(R.id.editTextSearch);
        String quarysearch = var1;

        ref = FirebaseDatabase.getInstance().getReference().child("Member");
        recyclerView = findViewById(R.id.docList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        options= new FirebaseRecyclerOptions.Builder<Member>().setQuery(ref.orderByChild("special").equalTo(quarysearch),Member.class).build();

        Query query = ref.orderByChild("special").equalTo(quarysearch);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Query query1 = ref.orderByChild("special").equalTo(quarysearch);
                if (dataSnapshot.exists()) {

                    searchbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String str= search.getText().toString();
                            firebaseSearch(str);
                        }
                    });

                    for (DataSnapshot issue : dataSnapshot.getChildren()) {
                        // do with your result

                        Toast.makeText(DoctorListActivity.this,var1,Toast.LENGTH_LONG).show();
                        adapter=new FirebaseRecyclerAdapter<Member, MyViewHolder>(options) {

                            @Override
                            protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Member model) {
                                holder.name.setText(" "+model.getName());
                                holder.speciality.setText("    "+model.getSpeciality());
                                holder.hometown.setText("    "+model.getHometown());
                                holder.number = model.getNumber();
                                holder.latitute = model.getLatitute();
                                holder.longitute = model.getLogitute();
                                holder.special = model.getSpecial();
                                holder.photoid = model.getImageid();
                                sech=model.getSpecial();

                                holder.layout.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        Intent Intent=new Intent(DoctorListActivity.this,DoctorRecycleActivity.class);
                                        Intent.putExtra("name",model.getName());
                                        Intent.putExtra("speciality",model.getSpeciality());
                                        Intent.putExtra("hometown",model.getHometown());
                                        Intent.putExtra("number",model.getNumber());
                                        Intent.putExtra("latitute",model.getLatitute());
                                        Intent.putExtra("longitute",model.getLogitute());
                                        Intent.putExtra("photoid",model.getImageid());

                                        startActivity(Intent);
                                    }
                                });


                /*recyclerView.setOnClickListener(new AdapterView.OnClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?>parent,View view,int position,long id) {
                        Toast.makeText(DoctorListActivity.this,model.getName(),Toast.LENGTH_LONG).show();
                    }
                });*/

                            }


                            @NonNull
                            @Override
                            public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view_layout,parent,false);
                                return new MyViewHolder(v);
                            }
                        };
                        adapter.startListening();
                        recyclerView.setAdapter(adapter);
                    }
                }
                else
                {
                    Toast.makeText(DoctorListActivity.this,"No Doctors to this category",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



        searchbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str= search.getText().toString();
                firebaseSearch(str);
            }
        });


    }

    private void firebaseSearch(String searchText) {
        String quary = searchText;
        Query firebaseSearchQuery = ref.orderByChild("Search").startAt(quary).endAt(quary + "uf8ff");
        options= new FirebaseRecyclerOptions.Builder<Member>().setQuery(ref.orderByChild("hometown").equalTo(quary),Member.class).build();
        Toast.makeText(DoctorListActivity.this,searchText,Toast.LENGTH_LONG).show();

        Query query = ref.orderByChild("hometown").equalTo(quary);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Query query1 = ref.orderByChild("hometown").equalTo(quary);
                if (dataSnapshot.exists()) {
                    String str= search.getText().toString();
                    searchbtn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            firebaseSearch(str);
                        }
                    });

                    for (DataSnapshot issue : dataSnapshot.getChildren()) {
                        // do with your result

                        Toast.makeText(DoctorListActivity.this,"quary",Toast.LENGTH_LONG).show();
                        adapter=new FirebaseRecyclerAdapter<Member, MyViewHolder>(options) {

                            @Override
                            protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Member model) {
                                holder.name.setText(" "+model.getName());
                                holder.speciality.setText("    "+model.getSpeciality());
                                holder.hometown.setText("    "+model.getHometown());
                                holder.number = model.getNumber();
                                holder.latitute = model.getLatitute();
                                holder.longitute = model.getLogitute();
                                holder.special = model.getSpecial();
                                holder.photoid = model.getImageid();
                                sech=model.getSpecial();

                                holder.layout.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {


                                        Intent Intent=new Intent(DoctorListActivity.this,DoctorRecycleActivity.class);
                                        Intent.putExtra("name",model.getName());
                                        Intent.putExtra("speciality",model.getSpeciality());
                                        Intent.putExtra("hometown",model.getHometown());
                                        Intent.putExtra("number",model.getNumber());
                                        Intent.putExtra("latitute",model.getLatitute());
                                        Intent.putExtra("longitute",model.getLogitute());
                                        Intent.putExtra("photoid",model.getImageid());

                                        startActivity(Intent);
                                    }
                                });


                /*recyclerView.setOnClickListener(new AdapterView.OnClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?>parent,View view,int position,long id) {
                        Toast.makeText(DoctorListActivity.this,model.getName(),Toast.LENGTH_LONG).show();
                    }
                });*/

                            }


                            @NonNull
                            @Override
                            public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view_layout,parent,false);
                                return new MyViewHolder(v);
                            }
                        };
                        adapter.startListening();
                        recyclerView.setAdapter(adapter);
                    }
                }
                else
                {
                    Toast.makeText(DoctorListActivity.this,"No Doctors in this Town",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}