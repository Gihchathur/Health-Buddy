package com.gautam.medicinetime.doctor;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.gautam.medicinetime.R;
import com.gautam.medicinetime.medicine.MainActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class DoctorListActivity2 extends AppCompatActivity {

    DatabaseReference ref;
    RecyclerView recyclerView;
    EditText search;
    String sech;

    private FirebaseRecyclerOptions<Member> options;
    private FirebaseRecyclerAdapter<Member, MyViewHolder> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_list);

        search = findViewById(R.id.editTextSearch);

        String pquery="Cardiology";
        ref = FirebaseDatabase.getInstance().getReference().child("Member");
        Query sQuery = ref.orderByChild("Cardiology").startAt(pquery).endAt(pquery + "\uf8ff");
        recyclerView = findViewById(R.id.docList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //options= new FirebaseRecyclerOptions.Builder<Member>().setQuery(sQuery,Member.class).setLifecycleOwner(this).build();


        String quary = "Cardiology";
        Query firebaseSearchQuery = ref.orderByChild("Search").startAt(quary).endAt(quary + "uf8ff");
        options = new FirebaseRecyclerOptions.Builder<Member>().setQuery(firebaseSearchQuery, Member.class).build();

        adapter = new FirebaseRecyclerAdapter<Member, MyViewHolder>(options) {
            @NonNull
            @Override
            public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view_layout,parent,false);
                MyViewHolder viewHolder = new MyViewHolder(itemView);

                return null;
            }

            @Override
            protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Member model) {
                holder.name.setText(" " + model.getName());
                holder.speciality.setText("    " + model.getSpeciality());
                holder.hometown.setText("    " + model.getHometown());
                holder.number = model.getNumber();
                holder.latitute = model.getLatitute();
                holder.longitute = model.getLogitute();

                holder.photoid = model.getImageid();

                holder.layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent Intent = new Intent(DoctorListActivity2.this, DoctorRecycleActivity.class);
                        Intent.putExtra("name", model.getName());
                        Intent.putExtra("speciality", model.getSpeciality());
                        Intent.putExtra("hometown", model.getHometown());
                        Intent.putExtra("number", model.getNumber());
                        Intent.putExtra("latitute", model.getLatitute());
                        Intent.putExtra("longitute", model.getLogitute());
                        Intent.putExtra("photoid", model.getImageid());

                        startActivity(Intent);
                    }
                });

            }

        };
        adapter.startListening();
        recyclerView.setAdapter(adapter);


    }

    private void firebaseSearch(String searchText) {
        String quary = searchText.toLowerCase();
        Query firebaseSearchQuery = ref.orderByChild("Search").startAt(quary).endAt(quary + "uf8ff");
        options = new FirebaseRecyclerOptions.Builder<Member>().setQuery(firebaseSearchQuery, Member.class).build();

        adapter = new FirebaseRecyclerAdapter<Member, MyViewHolder>(options) {
            @NonNull
            @Override
            public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view_layout,parent,false);
                MyViewHolder viewHolder = new MyViewHolder(itemView);

                return null;
            }

            @Override
            protected void onBindViewHolder(@NonNull MyViewHolder holder, int position, @NonNull Member model) {
                holder.name.setText(" " + model.getName());
                holder.speciality.setText("    " + model.getSpeciality());
                holder.hometown.setText("    " + model.getHometown());
                holder.number = model.getNumber();
                holder.latitute = model.getLatitute();
                holder.longitute = model.getLogitute();

                holder.photoid = model.getImageid();

                holder.layout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent Intent = new Intent(DoctorListActivity2.this, DoctorRecycleActivity.class);
                        Intent.putExtra("name", model.getName());
                        Intent.putExtra("speciality", model.getSpeciality());
                        Intent.putExtra("hometown", model.getHometown());
                        Intent.putExtra("number", model.getNumber());
                        Intent.putExtra("latitute", model.getLatitute());
                        Intent.putExtra("longitute", model.getLogitute());
                        Intent.putExtra("photoid", model.getImageid());

                        startActivity(Intent);
                    }
                });

            }

        };
    }



}