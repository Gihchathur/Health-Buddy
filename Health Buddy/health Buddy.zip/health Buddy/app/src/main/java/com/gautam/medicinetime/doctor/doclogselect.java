package com.gautam.medicinetime.doctor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.gautam.medicinetime.R;

public class doclogselect extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doclogselect);

        ImageView close1,close2;
        close1= findViewById(R.id.register);
        close2= findViewById(R.id.signin);

        Paint paint = new Paint();
        paint.setAntiAlias(true);

        final Animation myAnim = AnimationUtils.loadAnimation(this, R.anim.bounce);
        close1.startAnimation(myAnim);
        final Animation myAnim2 = AnimationUtils.loadAnimation(this, R.anim.bounce2);
        close2.startAnimation(myAnim2);


        close1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        paint.setShadowLayer(10, 0, 0, Color.argb(255, 255, 0, 0));
        close1.setLayerPaint(paint);


        close1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent=new Intent(doclogselect.this,DoctorRegActivity.class);
                startActivity(Intent);
            }
        });
        close2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent=new Intent(doclogselect.this,DoctorLogActivity.class);
                startActivity(Intent);
            }
        });
    }
}