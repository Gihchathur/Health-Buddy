package com.gautam.medicinetime.doctor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.gautam.medicinetime.R;
import com.gautam.medicinetime.doctor.DoctorRegActivity;
import com.gautam.medicinetime.medicine.MainActivity;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.net.URI;
import java.sql.Ref;

public class DoctorHomeActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button btnLogout,btnSave,location;
    EditText name,speciality,hometown,number;
    ImageView profileImage;
    DatabaseReference reff;
    StorageReference reff_str;
    Member member;
    ImageView close;
    int PICK_IMAGE=1;
    public Uri imguri;
    int PLACE_PICKER_REQUEST=2;
    String latitute1,longitute2;
    String special="Null";

    private Spinner spinner;
    private static final String[] paths = {"Diabetes", "Radiology", "Neurology","Otology","Ophthalmology","Rhinology","Oral Health","Cardiology","Gasroenterology","Pulmonology","Hepatology","Gynecology","Urology","Osteology","Orthopedics"};

    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_home);
        btnLogout = findViewById(R.id.logout);
        btnSave = findViewById(R.id.save);
        location=findViewById(R.id.location);
        name=findViewById(R.id.editText11);
        speciality =findViewById(R.id.editText22);
        hometown =findViewById(R.id.editText33);
        number =findViewById(R.id.editText44);
        profileImage=findViewById(R.id.imageView3);



        spinner = (Spinner)findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(DoctorHomeActivity.this,
                android.R.layout.simple_spinner_item,paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        member=new Member();
        reff= FirebaseDatabase.getInstance().getReference().child("Member");
        reff_str= FirebaseStorage.getInstance().getReference("Images");

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intToMain = new Intent(DoctorHomeActivity.this, DoctorRegActivity.class);
                startActivity(intToMain);
            }
        });

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(DoctorHomeActivity.this,DocLocSelector.class));

                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                try {
                    startActivityForResult(builder.build(DoctorHomeActivity.this)
                            , PLACE_PICKER_REQUEST);
                } catch(GooglePlayServicesRepairableException e) {
                        e.printStackTrace();
                } catch(GooglePlayServicesNotAvailableException e)
                {
                        e.printStackTrace();
                }
            }
        });






        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileUploader();

                String imageid;
                imageid=System.currentTimeMillis()+"."+getExtention(imguri);


                StorageReference Ref= reff_str.child(imageid);

                Ref.putFile(imguri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                // Get a URL to the uploaded content
                                //Uri downloadUrl = taskSnapshot.getDownloadUrl();
                                Toast.makeText(DoctorHomeActivity.this ,"Image Upload Successfully",Toast.LENGTH_LONG).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                // ...
                            }
                        });

                //latitute1="6.842220";
                //longitute2="79.901189";
                member.setName(name.getText().toString().trim());
               member.setSpeciality(speciality.getText().toString().trim());
               member.setHometown(hometown.getText().toString().trim());
               member.setNumber(number.getText().toString().trim());
                member.setLatitute(latitute1);
                member.setLogitute(longitute2);
                member.setSpecial(special);
               member.setImageid(imageid);
               reff.push().setValue(member);
               Toast.makeText(DoctorHomeActivity.this, "Data Insert Successfully",Toast.LENGTH_LONG).show();


            }
        });

        close= findViewById(R.id.imageView2);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent=new Intent(DoctorHomeActivity.this,SetupActivity.class);
                startActivity(Intent);
            }
        });

        profileImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Filechooser();
            }
        });

    }

    private String getExtention(Uri uri)
    {
        ContentResolver cr= getContentResolver();
        MimeTypeMap mimeTypeMap=MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));

    }



    private void FileUploader()
    {
        String imageid;
        imageid=System.currentTimeMillis()+"."+getExtention(imguri);
        member.setImageid(imageid);

        StorageReference Ref= reff_str.child(imageid);

        Ref.putFile(imguri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // Get a URL to the uploaded content
                        //Uri downloadUrl = taskSnapshot.getDownloadUrl();
                        Toast.makeText(DoctorHomeActivity.this ,"Image Upload Successfully",Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                        // ...
                    }
                });

    }




    private void Filechooser(){
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        photoPickerIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(photoPickerIntent, PICK_IMAGE);

    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==1 && resultCode==RESULT_OK && data!=null && data.getData()!=null)
        {
            imguri = data.getData();
            profileImage.setImageURI(imguri);
        }

        if(requestCode==PLACE_PICKER_REQUEST)
        {
            if(resultCode==RESULT_OK)
            {
                Place place=PlacePicker.getPlace(data,this);
                StringBuilder stringBuilder= new StringBuilder();
                String Latitute=String.valueOf(place.getLatLng().latitude);
                String Logitute=String.valueOf(place.getLatLng().longitude);
                latitute1=Latitute;
                longitute2= Logitute;
            }


        }


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:
               special="Diabetes";
                break;
            case 1:
                special="Radiology";
                break;
            case 2:
                special= "Neurology";
                break;
            case 3:
                special="Otology";
                break;
            case 4:
                special="Ophthalmology";
                break;
            case 5:
                special="Rhinology";
                break;
            case 6:
                special="Oral Health";
                break;
            case 7:
                special="Cardiology";
                break;
            case 8:
                special="Gasroenterology";
                break;
            case 9:
                special="Pulmonology";
                break;
            case 10:
                special="Hepatology";
                break;
            case 11:
                special="Gynecology";
                break;
            case 12:
                special="Urology";
                break;
            case 13:
                special="Osteology";
                break;
            case 14:
                special="Orthopedics";
                break;



        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}